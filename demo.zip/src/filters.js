import React from 'react';
import './filter.css';

const Filter = () =>{
return(
    <div>
        <div className="card filterContainer">
            <div className="card-body">
                <h5><b>Filters</b></h5>
                <p>Launch Year</p><hr></hr>

        {/* years  */}
        <div id="myBtnContainer">
            <button className="btn years"> 2006</button>
            <button className="btn years"> 2007</button>
            <button className="btn years"> 2008</button>
            <button className="btn years"> 2009</button>
            <button className="btn years"> 2010</button>
            <button className="btn years"> 2011</button>
            <button className="btn years"> 2012</button>
            <button className="btn years"> 2013</button>
            <button className="btn years"> 2014</button>
            <button className="btn years"> 2015</button>
            <button className="btn years"> 2016</button>
            <button className="btn years"> 2017</button>
            <button className="btn years"> 2018</button>
            <button className="btn years"> 2019</button>
            <button className="btn years"> 2020</button>

            
            </div>

        </div>

        
    </div>

</div>

    
)
}

export default Filter;